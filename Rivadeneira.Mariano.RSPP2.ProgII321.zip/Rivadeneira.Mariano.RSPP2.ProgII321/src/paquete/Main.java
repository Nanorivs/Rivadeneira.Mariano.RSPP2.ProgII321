package paquete;


import model.Inventario;

import java.util.List;
import model.Almacenable;
import model.Categoria;
import model.DispositivoDomotico;

public class Main {

    public static void main(String[] args) {
        try {
            
            Almacenable<DispositivoDomotico> inv = new Inventario<>();
            inv.agregar(new DispositivoDomotico(1001, "AirPure S1", Categoria.AMBIENTAL, 35, 2023)); inv.agregar(new DispositivoDomotico(1002, "AssistGo Mini", Categoria.ASISTENCIA, 50, 2019)); inv.agregar(new DispositivoDomotico(1003, "SecureHome A7", Categoria.SEGURIDAD, 42, 2021)); inv.agregar(new DispositivoDomotico(1004, "AirPure X2", Categoria.AMBIENTAL, 28, 2022));
            
            inv.agregar(new DispositivoDomotico(1005, "AssistGo Pro", Categoria.ASISTENCIA, 60, 2020)); inv.agregar(new DispositivoDomotico(1006, "SafeWatch L3", Categoria.SEGURIDAD, 33, 2024));
            System.out.println("=== Inventario original ===");
            for (DispositivoDomotico d : inv.obtenerTodos()) {
            System.out.println(d);
            }
               // 1) Orden natural
            inv.ordenar(); System.out.println("\n=== Orden natural ===");
            for (DispositivoDomotico d : inv.obtenerTodos()) {
            System.out.println(d);
            }
            // 2) Ordenar por nombreModelo → completar Comparator
            inv.ordenar((o1,o2)->o1.getNombreModelo().compareToIgnoreCase(o2.getNombreModelo())); System.out.println("\n=== Ordenados por nombre de modelo ===");
            for (DispositivoDomotico d : inv.obtenerTodos()) {
            System.out.println(d);
            }
            // 3) Filtrar consumo <= 40W → completar Predicate System.out.println("\n=== Dispositivos con consumo <= 40W ===");
            List<DispositivoDomotico> filtrados =
            inv.filtrar((t)->t.getConsumoWatts()<=40);
            for (DispositivoDomotico d : filtrados) {
            System.out.println(d);
            }
            // 4) Transformación: ASISTENCIA con -15% consumo → completar Function System.out.println("\n=== Transformación (ASISTENCIA con -15% consumo) ===");
            List<DispositivoDomotico> transformados =
            inv.transformar(t -> t.getCategoria() == Categoria.ASISTENCIA
             ? new DispositivoDomotico(
                   t.getCodigo(),
                   t.getNombreModelo(),
                   t.getCategoria(),
                   (int)(t.getConsumoWatts() * 0.85),
                   t.getAnioFabricacion()
               )
             : t);
            for (DispositivoDomotico d : transformados) {
            System.out.println(d);
            }
            // 5) Contar fabricados desde 2020 → completar Predicate
            int recientes = inv.contar((t)->t.getAnioFabricacion() >= 2020); System.out.println("\nCantidad fabricados desde 2020: " + recientes);
             // 6) Persistencia
             inv.guardarEnBinario("rsc/data/inventario.bin"); inv.guardarEnCSV("rsc/data/inventario.csv"); 
            
            // 7) Cargar desde CSV → completar función fromCSV
            Almacenable<DispositivoDomotico> invCSV = new Inventario<>(); invCSV.cargarDesdeCSV("rsc/data/inventario.csv", DispositivoDomotico::getFromCSV);
            System.out.println("\n=== Inventario cargado desde CSV ===");
            for (DispositivoDomotico d : invCSV.obtenerTodos()) 
                { System.out.println(d); }
            
        
        } catch (Exception e) 
        
        { System.err.println("Error: " + e.getMessage());}
        
    
}
    
}
