package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import model.DispositivoDomotico;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;



public class Inventario<T extends DispositivoDomotico> implements Almacenable<T>{
    List<T> elementos = new ArrayList<>();
    @Override
    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        elementos.removeIf(criterio);
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for (T e : elementos) {
            if (criterio.test(e)) {
                return e;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
        Collections.sort(elementos);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        Collections.sort(elementos, comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();

        for (T e : elementos) {
            if (criterio.test(e)) {
                listaFiltrada.add(e);
            }
        }
        return listaFiltrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> listaTransformada = new ArrayList<>();

        for (T e : elementos) {
            listaTransformada.add(operador.apply(e));
        }

        return listaTransformada;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;

        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(elementos);
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) deserializador.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))){
            T sample = elementos.getFirst();
            escritor.write(sample.getCSVheader());
            
            for(T e : elementos){
                escritor.write(e.toCSV());
            }            
        }
    }

@Override
public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
    List<T> lista = new ArrayList<>();

    try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {

        lector.readLine(); 
        
        String linea;
        while ((linea = lector.readLine()) != null) {
            lista.add(fromCSV.apply(linea));  
        }
    }

    elementos = lista;
}


    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        
    }

 



    
    
    
   



    
}
