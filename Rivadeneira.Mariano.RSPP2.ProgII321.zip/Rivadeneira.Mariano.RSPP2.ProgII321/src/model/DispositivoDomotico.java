package model;

import model.Categoria;


public class DispositivoDomotico implements CSVConvertible,Comparable<DispositivoDomotico>{


    
    private int codigo;
    private String nombreModelo;
    private Categoria categoria; 
    private int consumoWatts;
    private int anioFabricacion;

    public DispositivoDomotico(int codigo, String nombreModelo, Categoria categoria, int consumoWatts, int anioFabricacion) {
        this.codigo = codigo;
        this.nombreModelo = nombreModelo;
        this.categoria = categoria;
        this.consumoWatts = consumoWatts;
        this.anioFabricacion = anioFabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getConsumoWatts() {
        return consumoWatts;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    @Override
    public String toCSV() {
        StringBuilder cadena = new StringBuilder();
        cadena.append(codigo);
        cadena.append(",");
        cadena.append(nombreModelo);
        cadena.append(",");
        cadena.append(categoria);
        cadena.append(",");
        cadena.append(consumoWatts);
        cadena.append(",");
        cadena.append(anioFabricacion);
        cadena.append("\n");
        return cadena.toString();
    }
    public String getCSVheader(){
        return "codigo,nombreModelo,categoria,consumoWatts,anioFabricacion\n";
    }
    public static DispositivoDomotico getFromCSV(String datosCSV){
        String[] datos = datosCSV.split(",");
        return new DispositivoDomotico(
                Integer.parseInt(datos[0]),
                datos[1],
                Categoria.valueOf(datos[2]),
                Integer.parseInt(datos[3]),
                Integer.parseInt(datos[4])
        );
    }

    @Override
    public String toString() {
        return "DispositivoDomotico{" + "codigo=" + codigo + ", nombreModelo=" + nombreModelo + ", categoria=" + categoria + ", consumoWatts=" + consumoWatts + ", anioFabricacion=" + anioFabricacion + '}';
    }

    @Override
    public int compareTo(DispositivoDomotico o) {
        return Integer.compare(codigo, o.getCodigo());
    }

}
